package com.example.englishmemory;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class GameActivity extends Activity {
    
    private GridLayout gridLayout;
    private TextView movesTextView;
    private TextToSpeech tts;
    
    private int gridSize;
    private String topic;
    private int moves = 0;
    private int matchesFound = 0;
    
    private List<Card> cards = new ArrayList<>();
    private Card firstCard = null;
    private Card secondCard = null;
    private boolean isProcessing = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        
        gridLayout = findViewById(R.id.gridLayout);
        movesTextView = findViewById(R.id.movesTextView);
        
        gridSize = getIntent().getIntExtra("GRID_SIZE", 10);
        topic = getIntent().getStringExtra("TOPIC");
        
        // Initialize Text-to-Speech
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.US);
                }
            }
        });
        
        setupGame();
    }
    
    private void setupGame() {
        movesTextView.setText("צעדים: 0");
        
        List<String> words = getWordsForTopic(topic);
        
        // Take only half the grid size (since each pair has 2 cards)
        int pairsNeeded = gridSize / 2;
        words = words.subList(0, Math.min(pairsNeeded, words.size()));
        
        // Create pairs: text and image cards
        cards.clear();
        for (String word : words) {
            cards.add(new Card(word, CardType.TEXT));
            cards.add(new Card(word, CardType.IMAGE));
        }
        
        // Shuffle cards
        Collections.shuffle(cards);
        
        // Setup grid
        int columns = (int) Math.ceil(Math.sqrt(gridSize));
        gridLayout.setColumnCount(columns);
        gridLayout.removeAllViews();
        
        // Create card views
        int cardSize = getResources().getDisplayMetrics().widthPixels / (columns + 1);
        
        for (final Card card : cards) {
            final LinearLayout cardLayout = createCardView(card, cardSize);
            gridLayout.addView(cardLayout);
            
            cardLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onCardClicked(card, cardLayout);
                }
            });
        }
    }
    
    private LinearLayout createCardView(Card card, int size) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundResource(R.drawable.card_back);
        
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = size;
        params.height = size;
        params.setMargins(8, 8, 8, 8);
        layout.setLayoutParams(params);
        
        card.cardView = layout;
        
        return layout;
    }
    
    private void onCardClicked(Card card, LinearLayout cardLayout) {
        if (isProcessing || card.isFlipped || card.isMatched) {
            return;
        }
        
        // Flip the card
        flipCard(card, cardLayout);
        
        if (firstCard == null) {
            firstCard = card;
        } else if (secondCard == null) {
            secondCard = card;
            moves++;
            movesTextView.setText("צעדים: " + moves);
            
            // Check for match
            checkForMatch();
        }
    }
    
    private void flipCard(Card card, LinearLayout cardLayout) {
        card.isFlipped = true;
        cardLayout.removeAllViews();
        
        if (card.type == CardType.TEXT) {
            // Show text
            TextView textView = new TextView(this);
            textView.setText(card.word);
            textView.setTextSize(20);
            textView.setGravity(Gravity.CENTER);
            textView.setTextColor(0xFF000000);
            cardLayout.addView(textView);
            cardLayout.setBackgroundResource(R.drawable.card_front);
            
            // Speak the word
            speakWord(card.word);
            
        } else {
            // Show image with speaker button
            LinearLayout innerLayout = new LinearLayout(this);
            innerLayout.setOrientation(LinearLayout.VERTICAL);
            innerLayout.setGravity(Gravity.CENTER);
            
            // Image placeholder (you'll need to add actual images)
            TextView imageView = new TextView(this);
            imageView.setText(getEmojiForWord(card.word));
            imageView.setTextSize(50);
            imageView.setGravity(Gravity.CENTER);
            innerLayout.addView(imageView);
            
            // Speaker button
            Button speakerButton = new Button(this);
            speakerButton.setText("🔊");
            speakerButton.setTextSize(16);
            speakerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speakWord(card.word);
                }
            });
            innerLayout.addView(speakerButton);
            
            cardLayout.addView(innerLayout);
            cardLayout.setBackgroundResource(R.drawable.card_front);
        }
    }
    
    private void checkForMatch() {
        isProcessing = true;
        
        if (firstCard.word.equals(secondCard.word)) {
            // Match found!
            firstCard.isMatched = true;
            secondCard.isMatched = true;
            matchesFound++;
            
            firstCard = null;
            secondCard = null;
            isProcessing = false;
            
            // Check if game is complete
            if (matchesFound == gridSize / 2) {
                Toast.makeText(this, "כל הכבוד! סיימת את המשחק ב-" + moves + " צעדים!", Toast.LENGTH_LONG).show();
            }
            
        } else {
            // No match - flip back after delay
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    flipCardBack(firstCard);
                    flipCardBack(secondCard);
                    
                    firstCard = null;
                    secondCard = null;
                    isProcessing = false;
                }
            }, 1000);
        }
    }
    
    private void flipCardBack(Card card) {
        card.isFlipped = false;
        card.cardView.removeAllViews();
        card.cardView.setBackgroundResource(R.drawable.card_back);
    }
    
    private void speakWord(String word) {
        if (tts != null) {
            tts.speak(word, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }
    
    private List<String> getWordsForTopic(String topic) {
        List<String> words = new ArrayList<>();
        
        switch (topic) {
            case "colors":
                words.add("red");
                words.add("blue");
                words.add("green");
                words.add("yellow");
                words.add("orange");
                words.add("purple");
                words.add("pink");
                words.add("black");
                words.add("white");
                words.add("brown");
                break;
                
            case "animals":
                words.add("cat");
                words.add("dog");
                words.add("bird");
                words.add("fish");
                words.add("lion");
                words.add("elephant");
                words.add("monkey");
                words.add("tiger");
                words.add("bear");
                words.add("rabbit");
                break;
                
            case "food":
                words.add("apple");
                words.add("banana");
                words.add("bread");
                words.add("cheese");
                words.add("pizza");
                words.add("cake");
                words.add("cookie");
                words.add("milk");
                words.add("water");
                words.add("orange");
                break;
        }
        
        return words;
    }
    
    private String getEmojiForWord(String word) {
        // Return emoji representation of words
        switch (word.toLowerCase()) {
            // Colors - using colored circles
            case "red": return "🔴";
            case "blue": return "🔵";
            case "green": return "🟢";
            case "yellow": return "🟡";
            case "orange": return "🟠";
            case "purple": return "🟣";
            case "pink": return "🩷";
            case "black": return "⚫";
            case "white": return "⚪";
            case "brown": return "🟤";
            
            // Animals
            case "cat": return "🐱";
            case "dog": return "🐶";
            case "bird": return "🐦";
            case "fish": return "🐟";
            case "lion": return "🦁";
            case "elephant": return "🐘";
            case "monkey": return "🐵";
            case "tiger": return "🐯";
            case "bear": return "🐻";
            case "rabbit": return "🐰";
            
            // Food
            case "apple": return "🍎";
            case "banana": return "🍌";
            case "bread": return "🍞";
            case "cheese": return "🧀";
            case "pizza": return "🍕";
            case "cake": return "🎂";
            case "cookie": return "🍪";
            case "milk": return "🥛";
            case "water": return "💧";
            case "orange": return "🍊";
            
            default: return "❓";
        }
    }
    
    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
    
    // Inner classes
    enum CardType {
        TEXT, IMAGE
    }
    
    class Card {
        String word;
        CardType type;
        boolean isFlipped = false;
        boolean isMatched = false;
        LinearLayout cardView;
        
        Card(String word, CardType type) {
            this.word = word;
            this.type = type;
        }
    }
}
