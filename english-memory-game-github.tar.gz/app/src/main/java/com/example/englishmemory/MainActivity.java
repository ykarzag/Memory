package com.example.englishmemory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends Activity {
    
    private RadioGroup gridSizeGroup;
    private RadioGroup topicGroup;
    private Button startButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        gridSizeGroup = findViewById(R.id.gridSizeGroup);
        topicGroup = findViewById(R.id.topicGroup);
        startButton = findViewById(R.id.startButton);
        
        // Set default selections
        ((RadioButton)findViewById(R.id.size10)).setChecked(true);
        ((RadioButton)findViewById(R.id.topicColors)).setChecked(true);
        
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startGame();
            }
        });
    }
    
    private void startGame() {
        int selectedSizeId = gridSizeGroup.getCheckedRadioButtonId();
        int selectedTopicId = topicGroup.getCheckedRadioButtonId();
        
        int gridSize = 10;
        if (selectedSizeId == R.id.size12) gridSize = 12;
        else if (selectedSizeId == R.id.size14) gridSize = 14;
        else if (selectedSizeId == R.id.size16) gridSize = 16;
        else if (selectedSizeId == R.id.size18) gridSize = 18;
        else if (selectedSizeId == R.id.size20) gridSize = 20;
        
        String topic = "colors";
        if (selectedTopicId == R.id.topicAnimals) topic = "animals";
        else if (selectedTopicId == R.id.topicFood) topic = "food";
        
        Intent intent = new Intent(MainActivity.this, GameActivity.class);
        intent.putExtra("GRID_SIZE", gridSize);
        intent.putExtra("TOPIC", topic);
        startActivity(intent);
    }
}
